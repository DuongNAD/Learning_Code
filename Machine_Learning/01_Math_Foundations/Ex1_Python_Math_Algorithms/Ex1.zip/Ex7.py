result = []

for i in range(2000, 3001):
    if (i % 2 ==0):
        result.append(str(i)) 

print(', '.join(result))