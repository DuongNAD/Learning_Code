from collections import Counter

data2 = [4, 6, 4, 3, 3, 4, 3, 4, 3, 8]
k = 3
result = []
counts = Counter(data2)

for i in counts:
    if counts[i] > k:
        result.append(i)

print(result)