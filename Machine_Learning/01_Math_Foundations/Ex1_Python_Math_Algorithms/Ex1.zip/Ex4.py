data4 = [1, 2, 3]

for i in data4:
    for j in data4:
        for k in data4:
            if i != j and j != k and i != k:
                print(f"[{i}, {j}, {k}]")