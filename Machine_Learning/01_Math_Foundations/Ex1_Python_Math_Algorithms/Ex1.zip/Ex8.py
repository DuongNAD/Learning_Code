import os
from collections import defaultdict, deque

def find_shortest_word_chain(start_word, end_word, filename="wordsEn.txt"):
    if not os.path.exists(filename):
        return f"Lỗi: Không tìm thấy file '{filename}'"

    valid_words = set()
    prefix_map = defaultdict(list)

    try:
        with open(filename, 'r', encoding='utf-8') as file:
            for line in file:
                word = line.strip().lower()
                if len(word) >= 3:
                    valid_words.add(word)

                    prefix = word[:2]
                    prefix_map[prefix].append(word)
    except Exception as e:
        return f"Lỗi khi đọc file: {e} (File reading error)"

    start_word = start_word.strip().lower()
    end_word = end_word.strip().lower()

    if start_word not in valid_words or end_word not in valid_words:
        return "Từ nhập vào phải có ít nhất 3 chữ cái và tồn tại trong file wordsEn.txt."

    queue = deque([[start_word]]) 
    
    visited = {start_word}

    while queue:
        current_path = queue.popleft()
        last_word = current_path[-1]

        if last_word == end_word:
            return current_path

        suffix = last_word[-2:]

        for next_word in prefix_map.get(suffix, []):
            if next_word not in visited:
                visited.add(next_word)
                queue.append(current_path + [next_word])

    return "Không tìm thấy chuỗi nào kết nối 2 từ"

def main():

    start_word = input("Nhập từ 1: ")
    end_word = input("Nhập từ 2: ")

    result = find_shortest_word_chain(start_word, end_word)
    
    if isinstance(result, list):
        print("\nOutput:")
        print("\n".join(result))
    else:
        print("\n" + result)

if __name__ == "__main__":
    main()