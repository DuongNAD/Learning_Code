data3 = [4, 5, 6, 7, 3, 9, 11, 2, 10]
result = []

for i in range(len(data3) - 1):
    num = data3[i]      
    num_next = data3[i + 1] 
    
    result.append(max(num,num_next))

print(result)