data1 = [-10, -21, -4, -45, -66, 93, 11, -4, -6, 12, 11, 4]

pos_num = []
neg_num = []
pos_count = 0
neg_count = 0

for i in data1:
    if i < 0:
        neg_num.append(i)
        neg_count += 1
    else:
        pos_num.append(i)
        pos_count += 1

print("Positive numbers: ", pos_num)
print("Positive count: ", pos_count)
print("Negative numbers: ", neg_num)
print("Negative count: ", neg_count)