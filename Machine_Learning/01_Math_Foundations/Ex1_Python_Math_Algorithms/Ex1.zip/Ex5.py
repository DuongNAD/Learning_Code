data5_list1 = [[4, 3, 5], [1, 2, 3], [3, 7, 4]]
data5_list2 = [[1, 3], [9, 3, 5, 7], [8]]

result = []

for i in range(len(data5_list1)):

    tempt = list(dict.fromkeys(data5_list1[i] + data5_list2[i]))
    
    result.append(tempt)

print(result)